#include "stdio.h"
#include <iostream>

int main(){
    printf("Prevenindo loops infinitos");
    //sleep(5);
    //Fazendo agora o loop infinito, colocando um timeout de 45s
    //while(1);
    
}