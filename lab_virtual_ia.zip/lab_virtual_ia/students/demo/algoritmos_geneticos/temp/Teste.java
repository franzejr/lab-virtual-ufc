
class Teste{

public static void main(String[] args){
    Quadrado q = new Quadrado();
    System.out.println("dddsdsdsd");

}

}