class Quadrado{

	Quadrado(){
		System.out.println("Quadrado");
	}

}
