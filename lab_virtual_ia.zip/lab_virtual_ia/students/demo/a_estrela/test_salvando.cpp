#include "stdio.h" 
dd
int main(){

printf(" hduahdxx");


}