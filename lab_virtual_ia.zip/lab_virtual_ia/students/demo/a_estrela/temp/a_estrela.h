#include <cstdio>
#include <cstdlib>

int par(int num1){
	return num1 % 2;
}

int imprimirTexto(){
	printf("TEXTO QUE FOI IMPRESSO DO .h que esta dentro do /bin");
}
