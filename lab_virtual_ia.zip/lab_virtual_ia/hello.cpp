#finclude "stdio.h" 

int main(){

	printf("heuaheuah" );
}
