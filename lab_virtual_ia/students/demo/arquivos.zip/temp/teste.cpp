#include <iostream>

using namespace std;

int main(){
    cout << "Hello World from Web!!!!!"<< endl;
    cout << "Hello World!!!"<< endl;

}